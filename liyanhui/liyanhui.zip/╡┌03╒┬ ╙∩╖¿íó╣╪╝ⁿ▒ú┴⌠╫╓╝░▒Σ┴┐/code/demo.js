var str = "fdf\dfd";
reg = /\[\\\]/g;
alert(reg.test(str))

//下面这句是一条弹窗
//alert('标识符！');

//1.对代码进行说明，2.调试

/*
	sdfdsfdsf
	sdfdsfdsf
	sdfsdfdsf
	sdfsdfsdfsdf
	sdfdsfsdfsdfsdf
	sdfdsfsdf
	多行块级注释
*/

//var box  声明变量
//var box = 100 声明变量并且初始化
//alert(box)  以弹窗的方式输出box的值


//var boxString = '李炎恢';
//boxString = 100;
//alert(boxString);

//box = '李炎恢';
//alert(box);

//var box = '李炎恢';
//var age = 28;
//alert(box);
//alert(age);


var box = '李炎恢',
  age = 28,
  height = 178,
  width;

alert(width);
