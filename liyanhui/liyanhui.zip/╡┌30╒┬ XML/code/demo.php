<?php
	sleep(5);
?>