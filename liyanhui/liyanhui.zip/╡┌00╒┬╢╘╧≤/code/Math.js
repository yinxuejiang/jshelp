
/*
//返回介于 0 和 1 之间的伪随机数。
//Math.random( )
*/

/*
// ceil 方法 | floor 方法 | round 方法 
//Math.ceil(number)
*/


/*
// abs 方法 | exp 方法 |  max 方法 | min 方法 | pow 方法 |  sqrt 方法 
//Math.abs(number) 
*/


/*
// acos 方法 | asin 方法 | atan 方法 | atan2 方法 | cos 方法 | log 方法 | sin 方法 | tan 方法
//Math.sin(number) 
*/






