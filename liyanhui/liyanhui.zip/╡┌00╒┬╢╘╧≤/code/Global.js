/*
//escape 方法 | eval 方法 | isFinite 方法 | isNaN 方法 | parseFloat 方法 | parseInt 方法 | unescape 方法
*/

/*
//encodeURI | decodeURI 方法  | encodeURIComponent 方法 | decodeURIComponent 方法 | 

//":"、"/"、";" 和 "?" encodeURIComponent进行编码
var str1 = "yinxuejiang尹学江/";
var str2 = encodeURI(str1);
console.log(str2);

var str3 = encodeURIComponent(str1);
console.log(str3);
console.log( decodeURIComponent(str3) );
*/

/*
//eval(codeString)
//检查 JScript 代码并执行. 

eval("var mydate = new Date();");
*/








