/*
//toString()
//如果 Boolean 值是 true，则返回 “true”。否则，返回 “false”。
*/
/*
//valueOf()
*/
var a = true;
console.log( a.toString() );










