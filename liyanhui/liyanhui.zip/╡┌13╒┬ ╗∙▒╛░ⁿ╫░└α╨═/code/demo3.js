/*
var box = 'Mr. Lee';
//alert(box.toLowerCase());		//小写
//alert(box.toUpperCase());		//大写
alert(box.toLocaleLowerCase());
alert(box.toLocaleUpperCase());
*/

/*
//var box = 'Mr. Lee';
//alert(box.match('L'));		//找到L即返回L
//alert(box.match(','));			//没找到null
//alert(box.search('L'));		//找到L的位置
//alert(box.replace('L', 'Q'));	//替换
//alert(box.split(' '));		//分割成数组
//alert(String.fromCharCode(76));	//放一个ascii码
*/

/*
//var box = 'Lee';
//alert(box.localeCompare('Lee'));	//0
//alert(box.localeCompare('Aee'));		//1
//alert(box.localeCompare('Zee'));		//-1
//alert(box.localeCompare('6576'));
//alert(box.localeCompare('哎'));
//alert(box.localeCompare('周'));
*/

/*
var box = '百度';
alert(box.link('http://www.baidu.com'));
alert(box.bold());
*/








