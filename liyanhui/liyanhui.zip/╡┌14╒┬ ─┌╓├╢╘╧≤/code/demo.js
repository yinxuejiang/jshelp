/*
var box = 'Lee';
alert(Global.box);
*/

/*
var box = 'Lee';
alert(window.box);
*/

/*
var box = '//Lee��';
var a = encodeURI(box);
var b = encodeURIComponent(box);
alert(decodeURI(a));
alert(decodeURIComponent(b));
*/

/*
eval('var box = 100');
alert(box);
*/

/*
eval('alert(100)');
eval('function box() {return 123}');
alert(box());
alert(window.Array);
*/




















