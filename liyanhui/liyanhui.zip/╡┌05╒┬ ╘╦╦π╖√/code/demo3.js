

/*
var box = 25 >>> 2;
alert(box);
var box = 100; 			//将100赋值给box变量
box = box +100;			//box + 100赋值给box
var box = 100;
//box += 100;				//box = box +100;
box -= 100;				//box = box -100;
alert(box);
*/

/*
var box = 100, age = 200, height = 300;

alert(height);

var box = (1,2,3,4,5);

var box = {
	1 : 2,
	3 : 4,
	5 : 6
};
alert(box[1]);

var box = '';

if (3 > 4) {
	box = '对';
} else {
	box = '错';
}

var box = 3 > 4 ? '对' : '错';
alert(box);

var box = (5 - 4) * 8;



var box = (5 - 4) * 8;
alert(box);
*/














