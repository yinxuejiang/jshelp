<script type="text/javascript" src="base.js"></script>
<script type="text/javascript">
	addEvent(document, 'click', function () {
		alert("<?php echo Date('Y-m-d H:i:s')?>");
	});
</script>