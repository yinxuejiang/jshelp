/*
var box = "Lee";
var box2 = 'Lee';
alert(box+box2);
*/

/*
var box = 'Lee";		//引号必须成对
alert(box);
*/

/*
alert('\t\\L\'e\ne\"')
*/

/*
alert('\x41');
*/

/*
alert('\u03a3');
*/

/*
var box = 'Mr.';
box = box + ' Lee';
alert(box);
*/

/*
var box = true;
alert(box.toString());		//   'true'
*/

/*
var box = 10;
alert(box.toString());
alert(box.toString(2));			// '1010'
alert(box.toString(8));			// '12'
alert(box.toString(10));			// '10'
alert(box.toString(16));			// 'a'
*/

/*
var box;
alert(String(box));			// 'null'		//  'undefined'
*/

/*
var box = null;

var box = {};			//对象字面量的创建方法
alert(typeof box);
*/

/*
var box = new Object();			//通过new创建一个对象
alert(typeof box);
*/

/*
var box = new Object(2);
var age = 100;
alert(box + age);
*/

/*
var box = new Number(60);			//这种方法也是创建一个数值对象
alert(box);
*/

/*
 var box = new String('Lee');		//var box = 'Lee';
 alert(typeof box);
*/















