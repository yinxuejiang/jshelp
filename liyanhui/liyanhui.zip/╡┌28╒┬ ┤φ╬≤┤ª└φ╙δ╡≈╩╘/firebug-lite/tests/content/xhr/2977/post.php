<?php
echo $_POST['param2']; 
?>